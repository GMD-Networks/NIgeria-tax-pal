<?php
/**
 * TaxPal API Configuration
 * UPDATE THESE VALUES for your cPanel environment
 */

function envOrDefault(string $key, $default = '') {
    $value = getenv($key);
    if ($value === false || $value === null || $value === '') {
        return $default;
    }
    return $value;
}

// Database
define('DB_HOST', envOrDefault('DB_HOST', 'localhost'));
define('DB_NAME', envOrDefault('DB_NAME', 'taxpal_db'));          // Create this in cPanel MySQL Databases
define('DB_USER', envOrDefault('DB_USER', 'taxpal_user'));        // Create this in cPanel MySQL Databases
define('DB_PASS', envOrDefault('DB_PASS', 'YOUR_DB_PASSWORD'));   // Set a strong password

// JWT Secret - CHANGE THIS to a random 64+ character string
define('JWT_SECRET', envOrDefault('JWT_SECRET', 'CHANGE_THIS_TO_A_RANDOM_64_CHAR_STRING_FOR_SECURITY'));
define('JWT_EXPIRY', (int)envOrDefault('JWT_EXPIRY', 86400 * 30)); // 30 days

// Optional external JWT secret (only needed if accepting tokens from another auth provider)
define('EXTERNAL_JWT_SECRET', envOrDefault('EXTERNAL_JWT_SECRET', ''));

// Flutterwave
define('FLW_SECRET_KEY', envOrDefault('FLW_SECRET_KEY', 'YOUR_FLUTTERWAVE_SECRET_KEY'));
define('FLW_PUBLIC_KEY', envOrDefault('FLW_PUBLIC_KEY', 'YOUR_FLUTTERWAVE_PUBLIC_KEY'));
define('FLW_WEBHOOK_HASH', envOrDefault('FLW_WEBHOOK_HASH', 'YOUR_FLUTTERWAVE_WEBHOOK_HASH'));

// App
define('APP_URL', envOrDefault('APP_URL', 'https://taxpal.gmd-networks.com.ng'));
define('API_URL', envOrDefault('API_URL', 'https://taxpal.gmd-networks.com.ng/api'));

// AI provider
define('AI_API_URL', envOrDefault('AI_API_URL', 'https://api.openai.com/v1/chat/completions'));
define('AI_API_KEY', envOrDefault('AI_API_KEY', envOrDefault('OPENAI_API_KEY', '')));
define('AI_MODEL', envOrDefault('AI_MODEL', 'gpt-4o-mini'));

// Email defaults
define('SMTP_HOST', envOrDefault('SMTP_HOST', ''));
define('SMTP_PORT', (int)envOrDefault('SMTP_PORT', 587));
define('SMTP_USERNAME', envOrDefault('SMTP_USERNAME', ''));
define('SMTP_PASSWORD', envOrDefault('SMTP_PASSWORD', ''));
define('SMTP_ENCRYPTION', envOrDefault('SMTP_ENCRYPTION', 'tls'));
define('SMTP_FROM_EMAIL', envOrDefault('SMTP_FROM_EMAIL', 'noreply@taxpal.gmd-networks.com.ng'));
define('SMTP_FROM_NAME', envOrDefault('SMTP_FROM_NAME', 'TaxPal'));

// Free tier limits (per month)
define('FREE_LIMITS', [
    'calculator' => 5,
    'invoice' => 5,
    'chat' => 5,
]);

// Plan pricing
define('PLAN_TIERS', [
    'quarterly' => ['price' => 999, 'duration' => 3, 'name' => '3 Months'],
    'biannual'  => ['price' => 1499, 'duration' => 6, 'name' => '6 Months'],
    'annual'    => ['price' => 2499, 'duration' => 12, 'name' => '1 Year'],
]);
