<?php
/**
 * AI Proxy Routes - Tax Chat, Receipt OCR, Content Generation
 * Proxies to OpenAI-compatible API
 */

function handleTaxAiChat($db, $userId, $body) {
    if (!AI_API_KEY) {
        jsonResponse(['error' => 'AI API key not configured. Please set AI_API_KEY in config.php'], 500);
    }

    $messages = $body['messages'] ?? [];
    $messageCount = $body['messageCount'] ?? 0;

    // Add system prompt
    $systemPrompt = "You are TaxBot, a Nigerian tax assistant. Give short (2-3 sentence) answers about Nigerian taxes (PAYE, VAT, WHT, CIT, CGT). Always recommend consulting a tax expert for detailed advice. Current Nigerian tax info: VAT is 7.5%, PAYE uses graduated rates from 7-24%.";

    if ($messageCount >= 2) {
        $systemPrompt .= " After 2 messages, remind the user they can chat with a live consultant for personalized advice.";
    }

    array_unshift($messages, ['role' => 'system', 'content' => $systemPrompt]);

    $shouldStream = !array_key_exists('stream', $body) || $body['stream'] !== false;

    if ($shouldStream) {
        // Stream response
        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');
        header('Connection: keep-alive');
    }

    $ch = curl_init(AI_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . AI_API_KEY,
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => AI_MODEL,
            'messages' => $messages,
            'stream' => $shouldStream,
            'max_tokens' => 500,
            'temperature' => 0.7,
        ]),
        CURLOPT_RETURNTRANSFER => !$shouldStream,
        CURLOPT_WRITEFUNCTION => $shouldStream ? function($ch, $data) {
            echo $data;
            if (ob_get_level() > 0) ob_flush();
            flush();
            return strlen($data);
        } : null,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($shouldStream) {
        exit;
    }

    if ($response === false) {
        jsonResponse(['error' => 'AI request failed: ' . ($curlError ?: 'Unknown cURL error')], 502);
    }
    if ($httpCode !== 200) {
        $decoded = json_decode($response, true);
        if (is_array($decoded) && isset($decoded['error']['message'])) {
            jsonResponse(['error' => $decoded['error']['message']], 502);
        }
        jsonResponse(['error' => 'AI request failed', 'httpCode' => $httpCode], 502);
    }

    $decoded = json_decode($response, true);
    if (is_array($decoded) && isset($decoded['choices'][0]['message']['content'])) {
        jsonResponse(['success' => true, 'data' => ['content' => $decoded['choices'][0]['message']['content']]]);
    }

    jsonResponse(['error' => 'AI response missing content'], 502);
}

function handleReceiptOcr($db, $userId, $body) {
    if (!AI_API_KEY) {
        jsonResponse(['error' => 'AI API key not configured'], 500);
    }

    $image = $body['image'] ?? '';
    if (!$image) {
        jsonResponse(['error' => 'No image provided'], 400);
    }

    $prompt = 'Analyze this document image. Extract: document_type (receipt/invoice/resume/letter/report/form/id_document/other), title, raw_text, formatted_blocks (array of {text, style: heading1/heading2/heading3/body/subtitle/label/list_item, bold?, italic?}), and if financial: vendor_name, date, receipt_number, items (array of {description, quantity, unit_price, amount}), subtotal, tax_amount, tax_rate, total_amount, payment_method, currency. Also extract key_details as key-value pairs and sections with headings. Return valid JSON only.';

    $messages = [
        ['role' => 'system', 'content' => 'You are a document analysis AI. Extract structured data from images. Return only valid JSON.'],
        ['role' => 'user', 'content' => [
            ['type' => 'text', 'text' => $prompt],
            ['type' => 'image_url', 'image_url' => ['url' => $image]],
        ]],
    ];

    $ch = curl_init(AI_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . AI_API_KEY,
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => AI_MODEL,
            'messages' => $messages,
            'max_tokens' => 4000,
            'temperature' => 0.1,
        ]),
        CURLOPT_RETURNTRANSFER => true,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        jsonResponse(['error' => 'AI API error', 'success' => false], 500);
    }

    $result = json_decode($response, true);
    $content = $result['choices'][0]['message']['content'] ?? '';

    // Try to parse JSON from response
    $content = preg_replace('/```json\s*/', '', $content);
    $content = preg_replace('/```\s*$/', '', $content);
    $parsed = json_decode(trim($content), true);

    if (!$parsed) {
        $parsed = ['raw_text' => $content, 'document_type' => 'other'];
    }

    jsonResponse(['success' => true, 'data' => $parsed]);
}

function handleAutoTaxContent($db, $userId, $body) {
    if (!AI_API_KEY) {
        jsonResponse(['error' => 'AI API key not configured'], 500);
    }

    if (!Auth::isAdmin($db, $userId)) {
        jsonResponse(['error' => 'Admin access required'], 403);
    }

    $categories = ['paye', 'vat', 'wht', 'cit', 'cgt', 'updates', 'mistakes', 'stamp', 'levy'];
    $selectedCategories = array_rand(array_flip($categories), 3);

    $prompt = "Generate 3 Nigerian tax educational articles for these categories: " . implode(', ', $selectedCategories) . ". For each article provide JSON with: title, content (300-500 words), category, title_yo (Yoruba), title_ha (Hausa), title_pcm (Nigerian Pidgin), title_ig (Igbo), content_yo, content_ha, content_pcm, content_ig. Return as a JSON array. Focus on practical Nigerian tax tips.";

    $ch = curl_init(AI_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . AI_API_KEY,
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => AI_MODEL,
            'messages' => [
                ['role' => 'system', 'content' => 'You are a Nigerian tax content writer. Generate educational articles about Nigerian taxes with translations. Return only valid JSON array.'],
                ['role' => 'user', 'content' => $prompt],
            ],
            'max_tokens' => 8000,
            'temperature' => 0.8,
        ]),
        CURLOPT_RETURNTRANSFER => true,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        jsonResponse(['error' => 'AI request failed: ' . ($curlError ?: 'Unknown cURL error'), 'success' => false], 502);
    }

    $result = json_decode($response, true);
    if (!is_array($result)) {
        jsonResponse(['error' => 'AI response was not valid JSON', 'success' => false], 502);
    }
    if (isset($result['error']['message'])) {
        jsonResponse(['error' => $result['error']['message'], 'success' => false, 'httpCode' => $httpCode], 502);
    }
    if ($httpCode !== 200) {
        jsonResponse(['error' => 'AI request failed', 'success' => false, 'httpCode' => $httpCode], 502);
    }

    $content = $result['choices'][0]['message']['content'] ?? '';
    $content = preg_replace('/```json\s*/', '', $content);
    $content = preg_replace('/```\s*$/', '', $content);
    $articles = json_decode(trim($content), true);

    if (!is_array($articles)) {
        jsonResponse(['error' => 'Failed to parse generated content', 'success' => false], 500);
    }

    $inserted = [];
    foreach ($articles as $article) {
        $id = generateUUID();
        $stmt = $db->prepare("INSERT INTO tax_content (id, title, content, category, title_yo, title_ha, title_pcm, title_ig, content_yo, content_ha, content_pcm, content_ig, icon) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $id,
            $article['title'] ?? 'Untitled',
            $article['content'] ?? '',
            $article['category'] ?? 'updates',
            $article['title_yo'] ?? null,
            $article['title_ha'] ?? null,
            $article['title_pcm'] ?? null,
            $article['title_ig'] ?? null,
            $article['content_yo'] ?? null,
            $article['content_ha'] ?? null,
            $article['content_pcm'] ?? null,
            $article['content_ig'] ?? null,
            'FileText',
        ]);
        $inserted[] = ['id' => $id, 'title' => $article['title'], 'category' => $article['category']];
    }

    jsonResponse(['success' => true, 'articles' => $inserted]);
}
